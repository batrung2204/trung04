package examine.examine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamineApplicationTests {

	@Test
	void contextLoads() {
	}

}
