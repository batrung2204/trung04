package examine.examine.controller;


import examine.examine.model.Employee;
import jakarta.annotation.PostConstruct;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@Controller
@SpringBootApplication
@RequestMapping("/employees")
public class EmployeeController {

    private List<Employee> employeeList;

    @PostConstruct
    private void loadData(){
        Employee employee1 = new Employee(1,"pham","hieu","hieu@gmail.com");
        Employee employee2 = new Employee(2,"nguyen","huy","huy@gmail.com");

        employeeList = new ArrayList<>();

        employeeList.add(employee1);
        employeeList.add(employee2);
    }


    @GetMapping("/list")
    public String listEmployees(Model model){
        model.addAttribute("employees",employeeList);
        return "list_employees";
    }
}
